<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.6.0/css/font-awesome.min.css" rel="stylesheet">
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.css" />
<link href="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.1/summernote.css" rel="stylesheet">
<script  src="//code.jquery.com/jquery-2.1.3.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.1/summernote.js"></script>
<title>Summernote - Image manager by futre</title>
</head>
<body>
<div class="container">
<div class="row">
<div class="col-md-12">
<h4 class="alert alert-info"><i class="fa fa-image"></i>&nbsp;&nbsp;Summernote Image manager by futre</h4>
<textarea class="form-control summernote" name="content" id="summernote"></textarea>
<p class="alert alert-warning">Please note Save and Delete buttons are disabled. In this version the Crop button is not implemented. Also php files, save.php and delete.php are just for testing, if you're going to use this plugin you will need to secure them. If you need more help feel free to <a href="http://www.fulviocorsini.it/" target="_blank">contact me</a>.</p>
</div>
</div>
</div>
<script src="js/image-manager.js"></script>
</body>
</html>
